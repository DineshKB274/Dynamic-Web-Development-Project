<?php
include ('C:\xampp\htdocs\project\connection.php');
session_start();
session_destroy();
header("Location:home.php");
?>