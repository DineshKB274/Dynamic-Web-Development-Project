<?php
    // Connect to database
    include('C:\xampp\htdocs\project\connection1.php');

    // Check for form submission
    if(isset($_POST['signin'])) {
        // Get user input
        $adminid =$_POST['adminid'];
        $password =$_POST['password'];

        // Validate user input
        if(empty($adminid)) {
            echo "Adminid is required.";
        }
        else if(empty($password)) {
            echo "Password is required.";
        }
        else {
            // Check if username and password match database
            $query = "SELECT * FROM admindata WHERE adminid='$adminid' AND password='$password'";
            $result = mysqli_query($con, $query);
            session_start();
            if(mysqli_num_rows($result) == 1) {

               $_SESSION['user'] = $adminid;
                header("Location:home2.php"); 
                // Login successful
                echo "Login successful.";
            }
            else {
                // Login failed
                echo "Incorrect adminid or password.";
            }
        }
    }
  
    // Check if user is already logged in
 //   if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
   //     header("Location:home.php");
     //   exit();
   // }


    if(isset($_POST['signup'])) {
        // Get user input
        $adminid = $_POST['adminid'];
        $password = $_POST['password'];
        $repeatpassword=$_POST['repeatpassword'];
        $email=$_POST['email'];
        // Validate user input
        if(empty($adminid)) {
            echo "Username is required.";
        }
        else if(empty($password)) {
            echo "Password is required.";
        }
        else if(empty($repeatpassword)) {
            echo "Please repeat your password.";
        }
        else if(empty($email)) {
            echo "Email is required.";
        }
        else if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email address.";
        }
        else if($password!=$repeatpassword) {
            echo "Passwords do not match.";
        }
        else{
            // Insert user data into database
            $query ="INSERT INTO admindata(adminid,password,repeatpassword,email) VALUES ('$adminid','$password','$repeatpassword','$email')";
            mysqli_query($con, $query);
                        // Set session variables
                    //    $_SESSION['username'] = $username;
                     //   $_SESSION['loggedin'] = true;
            
            echo "User registered successfully.";
            header("Location:home.php");
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="join.css">
    <title>join</title>
</head>
<body>
    <div class="login-wrap">
        <div class="login-html">
            <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
            <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
            <div class="login-form">
                <div class="sign-in-htm">
                <form method="post" action="join1.php">
                    <div class="group">
                        <label for="user" class="label"></label>
                        <input id="user" type="text" placeholder="Admin Id" class="input" name="adminid">
                    </div>
                    <div class="group">
                        <label for="pass" class="label"></label>
                        <input id="pass" type="password" class="input" placeholder="Password" data-type="password" name="password">
                    </div>
                    <div class="group">
                        <input id="check" type="checkbox" class="check" checked>
                        <label for="check"><span class="icon"></span> Keep me Signed in</label>
                    </div>
                    <div class="group">
                        <input type="submit" class="button" value="Sign In" name="signin">
                    </div>
                 <div class="hr"></div>
              <!--      <div class="foot-lnk">
                        <a href="#forgot">Forgot Password?</a>
                    </div> -->
                </form>
                </div>
                <div class="sign-up-htm">
                <form method="post" action="join1.php">
                    <div class="group">
                        <label for="user" class="label"></label>
                        <input id="user" type="text" placeholder="Admin Id" class="input" name="adminid">  <!--pattern="\d{2}B91A\w{4}"-->
                    </div>
                    <div class="group">
                        <label for="pass" class="label"></label>
                        <input id="pass" type="password" class="input" placeholder="Password" data-type="password" name="password">
                    </div>
                    <div class="group">
                        <label for="pass" class="label"></label>
                        <input id="pass" type="password" class="input" placeholder="Repeat Password" data-type="password" name="repeatpassword">
                    </div>
                    <div class="group">
                        <label for="pass" class="label"></label>
                        <input id="pass" type="text" placeholder="Email Address" class="input" name="email">
                    </div>
                    <div class="group">
                        <input type="submit" class="button" value="Sign Up" name="signup">
                    </div>
                    <div class="hr"></div>
                    <div class="foot-lnk">
                        <label for="tab-1">Already Member?</a>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div> 
</body>
</html>

