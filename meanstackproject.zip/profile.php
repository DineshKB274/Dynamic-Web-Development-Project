<?php
// Establishing connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teacher";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Checking the connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Inserting data into the table
if (isset($_POST['submit'])) {
    $profilename = $_POST["profilename"];
    $college = $_POST["college"];
    $contactnumber  = $_POST["contactnumber"];
    $projects = $_POST["projects"];
    $interest1 = $_POST["interest1"];
    $interest2 = $_POST["interest2"];
    $interest3 = $_POST["interest3"];
    $profilename1 = $_POST["profilename1"];
    $email = $_POST["email"];
    $class = $_POST["class"];
    $register = $_POST["register"];

$document1 = $_FILES["document1"]["name"];
$document2 = $_FILES["document2"]["name"];
$document3 = $_FILES["document3"]["name"];

// get the temporary location of the uploaded files
$document1_temp = $_FILES["document1"]["tmp_name"];
$document2_temp = $_FILES["document2"]["tmp_name"];
$document3_temp = $_FILES["document3"]["tmp_name"];

    

    $sql = "INSERT INTO profile(profilename,college,contactnumber,projects,document1,interest1,interest2,interest3,profilename1,email,class,document2,document3,register)
    VALUES ('$profilename', '$college', '$contactnumber', '$projects', 
    LOAD_FILE('$document1'),'$interest1','$interest2','$interest3','$profilename1','$email','$class',
    LOAD_FILE('$document2'),LOAD_FILE('$document3'),'$register')";
  
  if (mysqli_query($conn, $sql)) {
    echo "Data added successfully.";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}

// Closing the connection
mysqli_close($conn);
?>



<!DOCTYPE html>
<html lang="en">
<link href="profile.css" rel="stylesheet">
<body>
    <center>
    <h1><center>Student Profile </center></h1>
    <p>Remember to fill every detail</p>
    </center>
<form method="post" action="profile.php">
    
    <div style="display:flex">
    
        
        <div class="container" style="flex:1;margin-right:20px;">
           
    <hr><b>Profile Name</b></label>
    <input type="text" placeholder="Enter your first name" name="profilename" required>
    <b>College</b>
    <input type="text" placeholder="Enter your college Name" name="college" required>
    

    <b>Contact Number</b>
    <input type="text" placeholder="Enter your whatsapp number" name="contactnumber" required>
    <b>Projects</b>
    <input type="text" placeholder="Title out the projects you have done" name="projects" required>

    <label for="document-upload"><b>Upload your Identification proof (Format:.pdf,.doc,.docx)</b></label>
    <input type="file" id="document-upload" name="document1" accept=".pdf,.doc,.docx">
    <button type="submit">Upload</button>
    <br>
    <label for="fields"><b>Areas of Interests</b></label>
    <input type="text" placeholder="e.g. CyberSecurity" name="interest1" required>
    <input type="text" placeholder="your interest 2" name="interest2" required>
    <input type="text" placeholder="your interest 3" name="interest3" required>
    <hr>

  </div>


  <div class="container" style="flex:1;margin-left:20px;">
  
    <hr><b>Profile Name</b></label>
    <input type="text" placeholder="Enter your last name" name="profilename1" required>
    <label for="email"><b>Registered Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required>
    <b>Class</b>
    <input type="text" placeholder="Batch and Branch(e.g. 3/4 CSE)" name="class" required>

    
    <label for="document-upload"><b>Resume (Format:.pdf,.doc,.docx)</b></label>
    <input type="file" id="document-upload" name="document2" accept=".pdf,.doc,.docx">
    <button type="submit">Upload</button>
    <label for="document-upload"><b>
      <br>
    Certificate (Format:.pdf,.doc,.docx)</b></label>
    <input type="file" id="document-upload" name="document3" accept=".pdf,.doc,.docx">
    <button type="submit">Upload</button>
    <br>
    <br>
    <b></b></label>
    <input type="text" placeholder="" required>
    <br>

    <b>Did you register before creating your profile</b></label>
    <input type="text" placeholder="Yes/No" name="register" required>
    <hr>


  </div>
  
 
    </div>
    <p style="color:rgb(195, 0, 255)"><center>Please remember your Details</center></p>
    <center><input type="submit" class="registerbtn" name="submit"></center>
    
        <center><h3>Already have a profile? <a href="join.php">Sign in</a></h3></center>
        <br>
        <br>
        <br>
      
</form>
</body>
</html>