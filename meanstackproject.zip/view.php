<?php
session_start();
?>

<link href="display.css" rel="stylesheet">
<body>
<div class="wrapper">
    <div class="sidebar">
       <div class="profile">
       <!---   <img src="C:\Users\grace\Desktop\icon.jpg"> -->
          <h3>Student Profile</h3>
        </div>
        <ul>
          <li>
            <a href="home1.php" class="active" >
              <span class="icon"><i class="fas fa-home"></i></span>
              <span class="item">Home</span>
            </a>
          </li>
          <li>
            <a href="view.php">
              <span class="icon"><i class="fas fa-desktop"></i></span>
              <span class="item">View profile</span>
            </a>
          </li>
          <li>
   <!--       <a href="#">
              <span class="icon"><i class="fas fa-user-friends"></i></span>
              <span class="item">Update details</span>
            </a>
          </li>
-->
        </ul>
      </div>
  <div class="section1">
    <form  method="post" name="f1" action="view.php">
        <center>
       <br> <h1><center><?php echo $_SESSION['user'] ?> Profile </center></h1><br>
        </center>
    
    <center>
      
        <div style="display:flex">
        
            
            <div class="container" style="flex:1;margin-right:20px;">
               
        <hr><b>Profile Name</b></label><br>
        <input type="text" placeholder='<?php echo $_SESSION['fname'] ?> <?php echo $_SESSION['lname'] ?>'><br>
        <b>College<br></b>
        <input type="text" placeholder="<?php echo $_SESSION['clg'] ?>"><br>
        
    
        <b>Contact Number<br></b>
        <input type="text" name="t1" placeholder="<?php echo $_SESSION['phn'] ?>"><br>
        <b>Projects<br></b>
        <input type="text" name="project"placeholder="<?php echo $_SESSION['pro'] ?>"><br>

        <label for="fields"><b>Areas of Interests</b></label><br><br>
        <input type="text" name="interest1"placeholder="<?php echo $_SESSION['int1'] ?>"><br>
        <input type="text" name="interest2"placeholder="<?php echo $_SESSION['int2'] ?>"><br>
        <input type="text"name="interest3" placeholder="<?php echo $_SESSION['int3'] ?>"><br>
        <br>
    
    

        <label for="email"><b>Registered Email</b></label><br>
        <input type="text" name="t2" placeholder="<?php echo $_SESSION['email'] ?>" id="email"><br>
        <b>Class</b><br>
        <input type="text" name="branch" placeholder="<?php echo $_SESSION['br'] ?>"><br>
        <b>Registered no.</b><br>
        <input type="text" name="rno" placeholder="<?php echo $_SESSION['reg'] ?>"><br>
        <b></b></label>
        <b>Interested in Higher Studies?<br>
        <input type="text" name="high" placeholder="<?php echo $_SESSION['higher'] ?>">
        <br>
        <hr>
    
    
      </div>
      
     
        </div>
          
      
          </form>
  </div>

</div>
</center>
</body>