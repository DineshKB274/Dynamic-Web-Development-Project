<?php
// Establishing connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teacher1";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Checking the connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Inserting data into the table
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $company = $_POST["company"];
  $names = $_POST["names"];
  $last_date = $_POST["last_date"];
  $link = $_POST["link"];
  $details = $_POST["details"];

  $sql = "INSERT INTO links (company, names, last_date, link, details)
  VALUES ('$company', '$names', '$last_date', '$link', '$details')";

  if (mysqli_query($conn, $sql)) {
    echo "Data added successfully.";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}

// Closing the connection
mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>profile</title>
    <!-- bootsrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   

    <link rel="stylesheet" href="addlinks.css">
      <header>
        <body>
       
          <!-- <h1>SRKR</h1> -->
                <!-- Nav Bar -->
       <nav class="navbar navbar-expand-lg navbar-dark">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="navImg">
            <img src="https://srkrec.edu.in/assets/img/logo.png">
          </div>
          <div class="title">
            <p>TRAINING AND PLACEMENT CELL</p>
          </div>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul  class="navbar-nav ms-auto Nav list-unstyled">  
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <div class="dropdown">
                  <button class="dropbtn">Choices</button>
                  <div class="dropdown-content">
                    <a href="jobs.html">Job</a>
                    <a href="courses.html">Courses</a>
                    <a href="internship.html">Internships</a>
                    <a href="competitions.html">Competions</a>
                    <a href="higherStu.html">Higher Studies</a>
                  </div>
                </div>
              </li>
              <li class="nav-item">
                <div class="dropdown btn-group dropstart">
                  <button class="dropbtn">Companies</button>
                  <div class="dropdown-content">
                    <a href="oncampus.html">On-Campus</a>
                    <a href="offcampus.html">Off-Campus</a>
                  </div>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="placement.html">Placements</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact8.html">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="join.html">Login</a>
              </li>
            </ul>
          </div>
        </nav>
        </header>

        </body>
</html>









<link href="addlink.css" rel="stylesheet">
<div class="header">

</div>
<div class="container mb-5"> 
  <div class="row"> 
    <input type="radio" name="box" id="one" onclick="displayRadioValue()"> 
    <input type="radio" name="box" id="two" onclick="displayRadioValue()"> 
    <input type="radio" name="box" id="three" onclick="displayRadioValue()"> 
    <input type="radio" name="box" id="four" onclick="displayRadioValue()"> 
    <input type="radio" name="box" id="five" onclick="displayRadioValue()"> 
    <label for="one" class="box first"> 
      <div class="course"> 
        <span class="circle"></span> 
        <span class="subject"> Courses</span> 
      </div>
    </label> 
    <label for="two" class="box second"> 
      <div class="course">
        <span class="circle"></span> 
        <span class="subject">Internships</span>
      </div>
    </label>
    <label for="three" class="box third"> 
      <div class="course"> 
        <span class="circle"></span> 
        <span class="subject"> Jobs </span>
      </div>
    </label>
    <label for="four" class="box forth"> 
      <div class="course">
        <span class="circle"></span> 
        <span class="subject"> HigherStudies </span>
      </div>
    </label>
    <label for="five" class="box fifth"> 
      <div class="course">
        <span class="circle"></span> 
        <span class="subject"> Competitions </span>
      </div>
    </label>
  </div> 
</div>


<br>

<div id="result">
  
</div>

<script>
  function displayRadioValue() {
  var result = document.getElementById("result");
  result.innerHTML = '';
  var ele = document.getElementsByName('box');
  
  for (i = 0; i < ele.length; i++) {
    if (ele[i].checked) {
      const form = document.createElement("form");
      form.method = "post";
      form.action = "addlink1.php";

      const company = document.createElement("input");
      company.type = "text";
      company.name = "company";
      company.placeholder = "Enter Company/Organization Name";
      form.appendChild(company);
      form.appendChild(document.createElement("br"));
      form.appendChild(document.createElement("br"));

      const name = document.createElement("input");
      name.type = "text";
      if (ele[i].id == "one")
        name.placeholder = "Enter Course Name";
      if (ele[i].id == "two")
        name.placeholder = "Enter Internship Name";
      if (ele[i].id == "three")
        name.placeholder = "Enter Job Name";
      if (ele[i].id == "four")
        name.placeholder = "Enter higher Name";
      if (ele[i].id == "five")
        name.placeholder = "Enter Competition Name";
      name.name = "names";
      form.appendChild(name);
      form.appendChild(document.createElement("br"));
      form.appendChild(document.createElement("br"));

      const last_date = document.createElement("input");
      last_date.type = "text";
      last_date.name = "last_date";
      last_date.placeholder = "Enter Last Date(Year/Month/Day)";
      form.appendChild(last_date);
      form.appendChild(document.createElement("br"));
      form.appendChild(document.createElement("br"));

      const link = document.createElement("input");
      link.type = "text";
      link.name = "link";
      link.placeholder = "Enter Link";
      form.appendChild(link);
      form.appendChild(document.createElement("br"));
      form.appendChild(document.createElement("br"));

      const details = document.createElement("input");
      details.name = "details";
      details.contentEditable = true;
      details.id = "linkdetails";
      form.appendChild(details);
      form.appendChild(document.createElement("br"));
      form.appendChild(document.createElement("br"));

      const submit = document.createElement("input");
      submit.type= "submit";
      submit.value = "Submit";
      form.appendChild(submit);
      result.appendChild(form);
      break;
}
}
}
</script>
