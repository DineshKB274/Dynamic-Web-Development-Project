
<html>
<style>
		body {
			background-color:#adeaea;
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center;
		}
		table {
			border-collapse: collapse;
			width: 100%;
			max-width: 800px;
			margin: 0 auto;
			background-color: rgba(255,255,255,0.8);
			box-shadow: 0 0 10px rgba(0,0,0,0.2);
		}
		th, td {
			padding: 20px;
			text-align: left;
			border: 1px solid #ddd;
		}
		th {
			background-color: #f2f2f2;
			color: #333;
			font-weight: bold;
		}
	</style>
<body>
        <form>
         <table>
          <tr>
           <th>S.No</th>
           <th>Name Of the Company</th>
           <th>CTC</th>
           <th>No of Selections</th>
          </tr>
<?php
include ('C:\xampp\htdocs\project\connection.php');
  $sql="SELECT * FROM `t1`";
  $run=mysqli_query($con,$sql);
  if(mysqli_num_rows($run)>0)
{
     while($row=mysqli_fetch_assoc($run))
     {
        ?>
        <tr>
            <th> <?php  echo $row['sno'].'<br>'; ?></th>
            <th> <?php  echo $row['company'].'<br>'; ?></th> 
            <th> <?php  echo $row['ctc'].'<br>'; ?></th> 
            <th> <?php  echo $row['selections'].'<br>'; ?></th> 
        </tr>     
        <?php    
        }
   
}
else{
    echo "Connection failed";
}

?>
              </table>
        </form>
</body>
</html>